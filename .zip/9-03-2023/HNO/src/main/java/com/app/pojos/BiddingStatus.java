package com.app.pojos;

public enum BiddingStatus {
APPLIED,SELECTED,RECEIVED
}
