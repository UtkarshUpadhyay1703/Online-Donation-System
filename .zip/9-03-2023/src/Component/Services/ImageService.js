import axios from "axios";

class ImageService{
    constructor(){
        this.url="http://localhost:8080/file";
    }
    AddDonorImage(,donor)
}
export default new ImageService;